import {state,reply} from './_common.mjs';
export default async()=>{try{const s=await state(),out={};for(const x of [...s.blocks,...s.bookings.filter(x=>x.status!=='cancelado')]){(out[x.date]??=[]).push(x.time)}return reply(out)}catch{return reply({error:'Erro de conexão'},503)}};
